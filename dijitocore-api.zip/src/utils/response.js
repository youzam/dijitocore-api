const { translate } = require("./i18n");

exports.success = (req, res, data, messageKey = "general.success") => {
  return res.status(200).json({
    success: true,
    message: translate(messageKey, req.locale),
    data,
  });
};
