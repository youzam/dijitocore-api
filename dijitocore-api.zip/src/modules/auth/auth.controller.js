const authService = require("./auth.service.js");
const catchAsync = require("../../utils/catchAsync.js");

/**
 * =====================================================
 * BUSINESS OWNER SIGNUP
 * =====================================================
 */
const ownerSignup = catchAsync(async (req, res) => {
  const result = await authService.ownerSignup(req.body);
  res.status(201).json(result);
});

/**
 * =====================================================
 * VERIFY EMAIL ADDRESS
 * =====================================================
 */
const verifyEmail = catchAsync(async (req, res) => {
  const result = await authService.verifyEmail(req.body.code);
  res.status(200).json(result);
});

/**
 * =====================================================
 * LOGIN / REFRESH / LOGOUT
 * =====================================================
 */
const login = catchAsync(async (req, res) => {
  const result = await authService.login(req.body);
  res.status(200).json(result);
});

const refresh = catchAsync(async (req, res) => {
  const result = await authService.refresh(req.body.refresh_token);
  res.status(200).json(result);
});

const logout = catchAsync(async (req, res) => {
  await authService.logout(req.auth);
  res.status(204).send();
});

/**
 * =====================================================
 * PASSWORD RESET
 * =====================================================
 */
const requestPasswordReset = catchAsync(async (req, res) => {
  await authService.requestPasswordReset(req.body.email);
  res.status(200).json({});
});

const resetPassword = catchAsync(async (req, res) => {
  const result = await authService.resetPassword(
    req.body.token,
    req.body.password,
  );

  res.status(200).json(result);
});

/**
 * =====================================================
 * CUSTOMER AUTH – IDENTIFY + OTP
 * =====================================================
 */
const customerIdentify = catchAsync(async (req, res) => {
  const result = await authService.customerIdentify(req.body.phone);
  res.status(200).json(result);
});

const customerRequestOtp = catchAsync(async (req, res) => {
  await authService.customerRequestOtp(req.body.phone, req.body.business_id);
  res.status(200).json({});
});

const customerVerifyOtp = catchAsync(async (req, res) => {
  const result = await authService.customerVerifyOtp(
    req.body.phone,
    req.body.business_id,
    req.body.otp,
  );
  res.status(200).json(result);
});

module.exports = {
  ownerSignup,
  login,
  refresh,
  logout,
  requestPasswordReset,
  resetPassword,
  customerIdentify,
  customerRequestOtp,
  customerVerifyOtp,
  verifyEmail,
};
