const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

let cachedSettings = null;
let lastFetch = 0;
const CACHE_TTL = 60000; // 60 sec

async function getSystemSettingsCached() {
  const now = Date.now();

  if (cachedSettings && now - lastFetch < CACHE_TTL) {
    return cachedSettings;
  }

  const settings = await prisma.systemSetting.findFirst();
  cachedSettings = settings;
  lastFetch = now;

  return settings;
}

module.exports = async (req, res, next) => {
  try {
    const url = req.originalUrl || "";

    // 🔍 Route detection (BASED ON REAL SCAN)
    const isAdminRoute = url.startsWith("/admin");
    const isHealthRoute = url === "/health" || url === "/metrics";

    // Always allow system routes
    if (isHealthRoute) return next();

    const settings = await getSystemSettingsCached();

    // Fail-safe
    if (!settings || !settings.featureFlags) return next();

    const flags = settings.featureFlags;

    // =========================
    // 🔴 EMERGENCY SHUTDOWN
    // =========================
    if (flags.EMERGENCY_SHUTDOWN === true) {
      if (!isAdminRoute) {
        return res.status(503).json({
          status: "error",
          message: "System is under emergency shutdown",
        });
      }
    }

    // =========================
    // 🔴 MAINTENANCE MODE (STRICT)
    // =========================
    if (flags.MAINTENANCE_MODE === true) {
      if (!isAdminRoute) {
        return res.status(503).json({
          status: "error",
          message: "System under maintenance",
        });
      }
    }

    // =========================
    // 🔴 API WRITE CONTROL
    // =========================
    const writeMethods = ["POST", "PUT", "PATCH", "DELETE"];

    if (
      flags.API_WRITE === false &&
      writeMethods.includes(req.method) &&
      !isAdminRoute
    ) {
      return res.status(403).json({
        status: "error",
        message: "Write operations are disabled",
      });
    }

    // =========================
    // 🔴 SaaS PAYMENTS CONTROL (CORRECTED)
    // =========================
    if (
      flags.PAYMENTS === false &&
      url.startsWith("/subscriptions") &&
      writeMethods.includes(req.method) &&
      !isAdminRoute
    ) {
      return res.status(403).json({
        status: "error",
        message: "Subscription payments are disabled",
      });
    }

    return next();
  } catch (error) {
    return next(error);
  }
};
