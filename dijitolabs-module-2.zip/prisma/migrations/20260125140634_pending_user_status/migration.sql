-- AlterEnum
ALTER TYPE "UserStatus" ADD VALUE 'PENDING';
