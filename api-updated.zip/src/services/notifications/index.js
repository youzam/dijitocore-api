const notificationService = require("./notification.service.js");

module.exports = notificationService;
