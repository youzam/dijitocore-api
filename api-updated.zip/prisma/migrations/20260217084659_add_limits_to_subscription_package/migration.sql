-- AlterTable
ALTER TABLE "SubscriptionPackage" ADD COLUMN     "limits" JSONB;
