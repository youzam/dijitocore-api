const express = require("express");
const router = express.Router();

const reportingController = require("./reporting.controller");
const validate = require("../../../middlewares/validate.middleware");
const reportingValidation = require("./reporting.validation");

const auth = require("../../../middlewares/auth.middleware");
const requirePermission = require("../../../middlewares/requirePermission.middleware");

// =============================
// GLOBAL MIDDLEWARES
// =============================
router.use(auth);

router.use(
  requirePermission({
    module: "reporting",
    action: "read",
    scope: "global",
  }),
);

// =============================
// ROUTES
// =============================

// 1. TRANSACTIONS
router.get(
  "/transactions",
  validate(reportingValidation.getReport),
  reportingController.getTransactionReport,
);

// 2. MONTHLY REVENUE
router.get(
  "/revenue/monthly",
  validate(reportingValidation.getReport),
  reportingController.getMonthlyRevenueReport,
);

// 3. SETUP FEES
router.get(
  "/setup-fees",
  validate(reportingValidation.getReport),
  reportingController.getSetupFeeReport,
);

// 4. SUBSCRIPTION REVENUE
router.get(
  "/subscription-revenue",
  validate(reportingValidation.getReport),
  reportingController.getSubscriptionRevenueReport,
);

// 5. REFUNDS
router.get(
  "/refunds",
  validate(reportingValidation.getReport),
  reportingController.getRefundReport,
);

// 6. COUPONS
router.get(
  "/coupons",
  validate(reportingValidation.getReport),
  reportingController.getCouponReport,
);

// 7. SUPPORT
router.get(
  "/support",
  validate(reportingValidation.getReport),
  reportingController.getSupportReport,
);

// 8. AUDIT
router.get(
  "/audit",
  validate(reportingValidation.getReport),
  reportingController.getAuditReport,
);

// 9. COMPLIANCE
router.get(
  "/compliance",
  validate(reportingValidation.getReport),
  reportingController.getComplianceReport,
);

// =============================
// ASYNC EXPORT
// =============================
router.get(
  "/export/:type",
  validate(reportingValidation.getReport),
  reportingController.createAsyncExport,
);

// HISTORY
router.get("/export/history", reportingController.getExportHistory);

// DOWNLOAD
router.get("/export/download/:id", reportingController.downloadExport);

module.exports = router;
