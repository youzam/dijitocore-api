const prisma = require('../../config/prisma');

module.exports.send = async ({
  businessId,
  userId = null,
  customerId = null,
  contractId = null,
  type,
  title,
  message,
}) => {
  if (!businessId) {
    throw new Error('businessId is required');
  }

  if (!userId && !customerId) {
    throw new Error('Either userId or customerId must be provided');
  }

  const notification = await prisma.notification.create({
    data: {
      businessId,
      userId,
      customerId,
      contractId,

      type,
      channel: 'IN_APP',

      title,
      message,

      status: 'SENT', // 🔥 in-app = instant delivery
      sentAt: new Date(),
    },
  });

  return {
    success: true,
    channel: 'IN_APP',
    notificationId: notification.id,
  };
};
