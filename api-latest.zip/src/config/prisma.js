const { PrismaClient } = require("@prisma/client");

/**
 * Centralized Prisma Client
 * - Single DB connection
 * - Full logging enabled
 * - No process lifecycle ownership
 */

const prisma = new PrismaClient({
  log: [
    { level: "query", emit: "event" },
    { level: "warn", emit: "event" },
    { level: "error", emit: "event" },
  ],
});

// 🔒 Prevent audit log modification (append-only enforcement)
prisma.$use(async (params, next) => {
  if (
    params.model === "AuditLog" &&
    ["update", "updateMany", "delete", "deleteMany"].includes(params.action)
  ) {
    throw new Error("Audit logs are immutable and cannot be modified.");
  }

  return next(params);
});

/**
 * =========================
 * DATABASE OBSERVABILITY
 * =========================
 */

prisma.$on("query", (e) => {
  console.log("[DB QUERY]", {
    query: e.query,
    params: e.params,
    durationMs: e.duration,
  });
});

prisma.$on("warn", (e) => {
  console.warn("[DB WARN]", e.message);
});

prisma.$on("error", (e) => {
  console.error("[DB ERROR]", e.message);
});

module.exports = prisma;
