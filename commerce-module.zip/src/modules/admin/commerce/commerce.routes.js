const express = require("express");
const router = express.Router();

const controller = require("./commerce.controller");

const auth = require("../../../middlewares/auth.middleware");
const requirePermission = require("../../../middlewares/permission.middleware");

// 🔐 GLOBAL AUTH
router.use(auth);

/**
 * =========================
 * TRANSACTIONS (LEDGER)
 * =========================
 */

router
  .route("/transactions")
  .get(
    requirePermission({ module: "COMMERCE", action: "READ" }),
    controller.getTransactions,
  );

router
  .route("/transactions/:id")
  .get(
    requirePermission({ module: "COMMERCE", action: "READ" }),
    controller.getTransaction,
  );

router
  .route("/transactions/:id/drilldown")
  .get(
    requirePermission({ module: "COMMERCE", action: "READ" }),
    controller.getTransactionDrilldown,
  );

/**
 * =========================
 * FINANCIAL CONTROLS
 * =========================
 */

router
  .route("/transactions/:id/refund")
  .post(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.refundTransaction,
  );

router
  .route("/transactions/:id/invoice")
  .post(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.regenerateInvoice,
  );

router
  .route("/adjustments")
  .post(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.createAdjustment,
  );

router
  .route("/credits")
  .post(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.allocateCredit,
  );

/**
 * =========================
 * COUPONS
 * =========================
 */

router
  .route("/coupons")
  .post(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.createCoupon,
  )
  .get(
    requirePermission({ module: "COMMERCE", action: "READ" }),
    controller.getCoupons,
  );

router
  .route("/coupons/apply")
  .post(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.applyCoupon,
  );

router
  .route("/coupons/:id")
  .patch(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.updateCoupon,
  );

/**
 * =========================
 * PACKAGES
 * =========================
 */

router
  .route("/packages")
  .post(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.createPackage,
  )
  .get(
    requirePermission({ module: "COMMERCE", action: "READ" }),
    controller.getPackages,
  );

router
  .route("/packages/:id")
  .get(
    requirePermission({ module: "COMMERCE", action: "READ" }),
    controller.getPackage,
  )
  .patch(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.updatePackage,
  );

router
  .route("/packages/:id/config")
  .patch(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.updatePackageConfiguration,
  );

router
  .route("/packages/:id/deactivate")
  .patch(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.deactivatePackage,
  );

/**
 * =========================
 * SUBSCRIPTION CONTROL (NEW)
 * =========================
 */

router
  .route("/subscriptions/:id/change-plan")
  .post(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.changeSubscriptionPlan,
  );

router
  .route("/subscriptions/:id/cancel")
  .post(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.cancelSubscription,
  );

router
  .route("/subscriptions/:id/extend")
  .post(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.extendSubscription,
  );

router
  .route("/subscriptions/:id/grace")
  .get(
    requirePermission({ module: "COMMERCE", action: "READ" }),
    controller.getGraceStatus,
  );

router
  .route("/subscriptions/:id/grace/extend")
  .post(
    requirePermission({ module: "COMMERCE", action: "WRITE" }),
    controller.extendGracePeriod,
  );

module.exports = router;
