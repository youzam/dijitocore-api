-- AlterTable
ALTER TABLE "Customer" ADD COLUMN     "pinHash" TEXT;
