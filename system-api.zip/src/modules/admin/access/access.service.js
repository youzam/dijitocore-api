const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const prisma = require("../../../config/prisma");
const {
  seedPermissions,
} = require("../../../database/seeders/permissionSeeder");
const {
  assignPermissionsToRoles,
} = require("../../../database/seeders/rolePermissionSeeder");

/*
|--------------------------------------------------------------------------
| SYSTEM BOOTSTRAP
|--------------------------------------------------------------------------
*/

exports.bootstrapSystemService = async ({ email, password, currency }) => {
  const existing = await prisma.systemSetting.findFirst();

  if (existing && existing.isBootstrapped) {
    throw new Error("System already bootstrapped");
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  return prisma.$transaction(async (tx) => {
    const settings = await tx.systemSetting.create({
      data: {
        currency,
        activePaymentGateway: "SELCOM",
        isBootstrapped: true,
        maxLoginAttempts: 5,
        lockTimeMinutes: 30,
      },
    });

    const admin = await tx.superAdmin.create({
      data: {
        email,
        password: hashedPassword,
        role: "SUPER_ADMIN",
        status: "ACTIVE",
        loginAttempts: 0,
        forcePasswordChange: false,
      },
    });

    await seedPermissions();
    await assignPermissionsToRoles();

    await tx.auditLog.create({
      data: {
        action: "SYSTEM_BOOTSTRAP",
        entityType: "System",
        entityId: settings.id,
        meta: {
          createdAdmin: admin.email,
        },
      },
    });

    return settings;
  });
};

/*
|--------------------------------------------------------------------------
| AUTH
|--------------------------------------------------------------------------
*/

exports.adminLogin = async ({ email, password }, req) => {
  const settings = await prisma.systemSetting.findFirst();

  const admin = await prisma.superAdmin.findFirst({
    where: { email },
  });

  if (!admin) {
    throw new Error("Invalid credentials");
  }

  /*
  |--------------------------------------------------------------------------
  | ACCOUNT LOCK CHECK
  |--------------------------------------------------------------------------
  */

  if (admin.lockUntil && admin.lockUntil > new Date()) {
    throw new Error("Account temporarily locked");
  }

  /*
  |--------------------------------------------------------------------------
  | PASSWORD CHECK
  |--------------------------------------------------------------------------
  */

  const passwordMatch = await bcrypt.compare(password, admin.password);

  if (!passwordMatch) {
    const attempts = admin.loginAttempts + 1;

    if (attempts >= settings.maxLoginAttempts) {
      const lockUntil = new Date(
        Date.now() + settings.lockTimeMinutes * 60 * 1000,
      );

      await prisma.superAdmin.update({
        where: { id: admin.id },
        data: {
          loginAttempts: attempts,
          lockUntil,
        },
      });

      throw new Error("Account locked due to failed login attempts");
    }

    await prisma.superAdmin.update({
      where: { id: admin.id },
      data: {
        loginAttempts: attempts,
      },
    });

    throw new Error("Invalid credentials");
  }

  /*
  |--------------------------------------------------------------------------
  | ACCOUNT STATUS
  |--------------------------------------------------------------------------
  */

  if (admin.status === "SUSPENDED") {
    throw new Error("Admin account suspended");
  }

  /*
  |--------------------------------------------------------------------------
  | RESET LOGIN ATTEMPTS
  |--------------------------------------------------------------------------
  */

  await prisma.superAdmin.update({
    where: { id: admin.id },
    data: {
      loginAttempts: 0,
      lockUntil: null,
    },
  });

  /*
  |--------------------------------------------------------------------------
  | LOAD ROLE PERMISSIONS
  |--------------------------------------------------------------------------
  */

  const rolePermissions = await prisma.rolePermission.findMany({
    where: { role: admin.role },
    include: { permission: true },
  });

  const permissions = rolePermissions.map(
    (p) =>
      `${p.permission.module}_${p.permission.action}_${p.permission.scope}`,
  );

  /*
  |--------------------------------------------------------------------------
  | GENERATE TOKEN
  |--------------------------------------------------------------------------
  */

  const token = jwt.sign(
    {
      id: admin.id,
      role: admin.role,
      permissions,
    },
    process.env.JWT_SECRET,
    { expiresIn: "1d" },
  );

  /*
  |--------------------------------------------------------------------------
  | CREATE SESSION
  |--------------------------------------------------------------------------
  */

  await prisma.adminSession.create({
    data: {
      adminId: admin.id,
      ip: req?.ip,
      userAgent: req?.headers["user-agent"],
      lastSeen: new Date(),
    },
  });

  return {
    token,
    requirePasswordChange: admin.forcePasswordChange,
    admin: {
      id: admin.id,
      email: admin.email,
      role: admin.role,
      status: admin.status,
    },
  };
};

exports.logoutAdmin = async (adminId) => {
  await prisma.adminSession.deleteMany({
    where: { adminId },
  });

  return { success: true };
};

/*
|--------------------------------------------------------------------------
| ADMIN MANAGEMENT
|--------------------------------------------------------------------------
*/

exports.createAdmin = async ({ email, password, role }) => {
  const existing = await prisma.superAdmin.findFirst({
    where: { email },
  });

  if (existing) {
    throw new Error("Admin email already exists");
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const admin = await prisma.superAdmin.create({
    data: {
      email,
      password: hashedPassword,
      role,
      status: "ACTIVE",
      loginAttempts: 0,
      forcePasswordChange: true,
    },
  });

  await prisma.auditLog.create({
    data: {
      action: "ADMIN_CREATED",
      entityType: "SuperAdmin",
      entityId: admin.id,
    },
  });

  return admin;
};

exports.listAdmins = async () => {
  return prisma.superAdmin.findMany({
    orderBy: { createdAt: "desc" },
  });
};

exports.getAdmin = async (adminId) => {
  const admin = await prisma.superAdmin.findUnique({
    where: { id: adminId },
  });

  if (!admin) {
    throw new Error("Admin not found");
  }

  return admin;
};

exports.updateAdmin = async (adminId, data) => {
  const admin = await prisma.superAdmin.findUnique({
    where: { id: adminId },
  });

  if (!admin) {
    throw new Error("Admin not found");
  }

  return prisma.superAdmin.update({
    where: { id: adminId },
    data,
  });
};

exports.suspendAdmin = async (adminId) => {
  const admin = await prisma.superAdmin.findUnique({
    where: { id: adminId },
  });

  if (!admin) {
    throw new Error("Admin not found");
  }

  const updated = await prisma.superAdmin.update({
    where: { id: adminId },
    data: {
      status: "SUSPENDED",
    },
  });

  await prisma.auditLog.create({
    data: {
      action: "ADMIN_SUSPENDED",
      entityType: "SuperAdmin",
      entityId: adminId,
    },
  });

  return updated;
};

/*
|--------------------------------------------------------------------------
| ROLES
|--------------------------------------------------------------------------
*/

exports.listRoles = async () => {
  return [
    "SUPER_ADMIN",
    "FINANCE_ADMIN",
    "SUPPORT_ADMIN",
    "SECURITY_ADMIN",
    "OPERATIONS_ADMIN",
    "READ_ONLY_AUDITOR",
  ];
};

exports.changeAdminRole = async (adminId, role) => {
  const admin = await prisma.superAdmin.findUnique({
    where: { id: adminId },
  });

  if (!admin) {
    throw new Error("Admin not found");
  }

  return prisma.superAdmin.update({
    where: { id: adminId },
    data: { role },
  });
};

/*
|--------------------------------------------------------------------------
| PROFILE
|--------------------------------------------------------------------------
*/

exports.getMyProfile = async (adminId) => {
  const admin = await prisma.superAdmin.findUnique({
    where: { id: adminId },
  });

  if (!admin) {
    throw new Error("Admin not found");
  }

  return admin;
};

exports.updateMyProfile = async (adminId, data) => {
  return prisma.superAdmin.update({
    where: { id: adminId },
    data,
  });
};

/*
|--------------------------------------------------------------------------
| PASSWORD
|--------------------------------------------------------------------------
*/

exports.changePassword = async (adminId, currentPassword, newPassword) => {
  const admin = await prisma.superAdmin.findUnique({
    where: { id: adminId },
  });

  const passwordMatch = await bcrypt.compare(currentPassword, admin.password);

  if (!passwordMatch) {
    throw new Error("Current password incorrect");
  }

  const hashedPassword = await bcrypt.hash(newPassword, 10);

  await prisma.superAdmin.update({
    where: { id: adminId },
    data: {
      password: hashedPassword,
      forcePasswordChange: false,
    },
  });

  return { success: true };
};

exports.resetAdminPassword = async (adminId, newPassword) => {
  const hashedPassword = await bcrypt.hash(newPassword, 10);

  await prisma.superAdmin.update({
    where: { id: adminId },
    data: {
      password: hashedPassword,
      forcePasswordChange: true,
      loginAttempts: 0,
      lockUntil: null,
    },
  });

  return { success: true };
};

/*
|--------------------------------------------------------------------------
| SESSIONS
|--------------------------------------------------------------------------
*/

exports.getMySessions = async (adminId) => {
  return prisma.adminSession.findMany({
    where: { adminId },
    orderBy: { createdAt: "desc" },
  });
};

exports.revokeSession = async (sessionId) => {
  await prisma.adminSession.delete({
    where: { id: sessionId },
  });

  return { success: true };
};
