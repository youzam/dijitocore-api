const prisma = require("../../config/prisma");

exports.assignPermissionsToRoles = async () => {
  const permissions = await prisma.permission.findMany();

  const superAdminPerms = permissions.map((p) => ({
    role: "SUPER_ADMIN",
    permissionId: p.id,
  }));

  for (const perm of superAdminPerms) {
    await prisma.rolePermission.upsert({
      where: {
        role_permissionId: {
          role: perm.role,
          permissionId: perm.permissionId,
        },
      },
      update: {},
      create: perm,
    });
  }
};
