src/modules/admin/

├── access/
│ └── access.service.js

├── analytics/
│ └── analytics.service.js

├── commerce/
│ ├── coupon.service.js
│ ├── financial.service.js
│ ├── ledger.service.js
│ ├── package.service.js
│ └── subscription-control.service.js

├── communication/
│ └── communication.service.js

├── compliance/
│ └── compliance.service.js

├── governance/
│ └── governance.service.js

├── operation/
│ └── operation.service.js

├── reporting/
│ └── reporting.service.js

├── security/
│ └── security.service.js

├── setting/
│ └── setting.service.js

├── support/
│ └── support.service.js
