const prisma = require("../../config/prisma");
const { logAudit } = require("../../utils/audit.helper");

/*
|--------------------------------------------------------------------------
| INTERNAL HELPERS
|--------------------------------------------------------------------------
*/

const createPolicyVersion = async (tx, policy, adminId) => {
  return tx.policyVersion.create({
    data: {
      policyId: policy.id,
      resource: policy.resource,
      retentionDays: policy.retentionDays,
      version: policy.version,
      createdById: adminId,
    },
  });
};

const createPurgeQueue = async (tx, dataRequestId) => {
  return tx.purgeQueue.create({
    data: {
      dataRequestId,
    },
  });
};

/*
|--------------------------------------------------------------------------
| DATA RETENTION POLICY
|--------------------------------------------------------------------------
*/

exports.createRetentionPolicy = async (data, adminId) => {
  return prisma.$transaction(async (tx) => {
    const existing = await tx.dataRetentionPolicy.findFirst({
      where: { resource: data.resource, isActive: true },
    });

    if (existing) {
      throw new Error("Active policy already exists");
    }

    const policy = await tx.dataRetentionPolicy.create({
      data: {
        resource: data.resource,
        retentionDays: data.retentionDays,
        createdById: adminId,
      },
    });

    await createPolicyVersion(tx, policy, adminId);

    await logAudit({
      tx,
      userId: adminId,
      entityType: "RETENTION_POLICY",
      entityId: policy.id,
      action: "RETENTION_POLICY_CREATED",
      metadata: {
        resource: policy.resource,
        retentionDays: policy.retentionDays,
      },
      module: "COMPLIANCE",
      actorType: "ADMIN",
    });

    return policy;
  });
};

exports.updateRetentionPolicy = async (policyId, data, adminId) => {
  return prisma.$transaction(async (tx) => {
    const existing = await tx.dataRetentionPolicy.findUnique({
      where: { id: policyId },
    });

    if (!existing) {
      throw new Error("Policy not found");
    }

    const updated = await tx.dataRetentionPolicy.update({
      where: { id: policyId },
      data: {
        retentionDays: data.retentionDays,
        version: existing.version + 1,
      },
    });

    await createPolicyVersion(tx, updated, adminId);

    await logAudit({
      tx,
      userId: adminId,
      entityType: "RETENTION_POLICY",
      entityId: policyId,
      action: "RETENTION_POLICY_UPDATED",
      metadata: {
        retentionDays: data.retentionDays,
      },
      module: "COMPLIANCE",
      actorType: "ADMIN",
    });

    return updated;
  });
};

exports.getRetentionPolicyByResource = async (resource) => {
  return prisma.dataRetentionPolicy.findFirst({
    where: {
      resource,
      isActive: true,
    },
  });
};

exports.listRetentionPolicies = async (query) => {
  const { resource, isActive } = query;

  return prisma.dataRetentionPolicy.findMany({
    where: {
      ...(resource && { resource }),
      ...(isActive !== undefined && { isActive }),
    },
    orderBy: { createdAt: "desc" },
  });
};

exports.toggleRetentionPolicy = async (policyId, isActive, adminId) => {
  const updated = await prisma.dataRetentionPolicy.update({
    where: { id: policyId },
    data: { isActive },
  });

  await logAudit({
    userId: adminId,
    entityType: "RETENTION_POLICY",
    entityId: policyId,
    action: isActive
      ? "RETENTION_POLICY_ACTIVATED"
      : "RETENTION_POLICY_DEACTIVATED",
    module: "COMPLIANCE",
    actorType: "ADMIN",
  });

  return updated;
};

/*
|--------------------------------------------------------------------------
| POLICY VERSION
|--------------------------------------------------------------------------
*/

exports.listPolicyVersions = async (policyId) => {
  return prisma.policyVersion.findMany({
    where: { policyId },
    orderBy: { version: "desc" },
  });
};

exports.getPolicyVersionById = async (versionId) => {
  return prisma.policyVersion.findUnique({
    where: { id: versionId },
  });
};

/*
|--------------------------------------------------------------------------
| DATA REQUESTS (EXPORT + DELETE)
|--------------------------------------------------------------------------
*/

exports.createDataRequest = async (data, adminId) => {
  const request = await prisma.dataRequest.create({
    data: {
      type: data.type,
      targetType: data.targetType,
      targetId: data.targetId,
      reason: data.reason,
      requestedById: adminId,
    },
  });

  await prisma.auditLog.create({
    data: {
      action: "CREATE_DATA_REQUEST",
      entity: "DataRequest",
      entityId: request.id,
      performedById: adminId,
    },
  });

  await logAudit({
    userId: adminId,
    entityType: "DATA_REQUEST",
    entityId: request.id,
    action: "DATA_REQUEST_CREATED",
    metadata: {
      type: request.type,
      targetType: request.targetType,
      targetId: request.targetId,
    },
    module: "COMPLIANCE",
    actorType: "ADMIN",
  });

  return request;
};

exports.listDataRequests = async (query) => {
  const { type, status } = query;

  return prisma.dataRequest.findMany({
    where: {
      ...(type && { type }),
      ...(status && { status }),
    },
    orderBy: { createdAt: "desc" },
  });
};

exports.getDataRequestById = async (requestId) => {
  return prisma.dataRequest.findUnique({
    where: { id: requestId },
  });
};

exports.approveDataRequest = async (requestId, adminId) => {
  return prisma.$transaction(async (tx) => {
    const request = await tx.dataRequest.findUnique({
      where: { id: requestId },
    });

    if (!request) throw new Error("Request not found");
    if (request.status !== "PENDING") throw new Error("Already processed");

    const updated = await tx.dataRequest.update({
      where: { id: requestId },
      data: {
        status: "APPROVED",
        approvedById: adminId,
        approvedAt: new Date(),
      },
    });

    if (request.type === "DELETE") {
      await createPurgeQueue(tx, request.id);
    }

    await logAudit({
      tx,
      userId: adminId,
      entityType: "DATA_REQUEST",
      entityId: request.id,
      action: "DATA_REQUEST_APPROVED",
      metadata: {
        type: request.type,
      },
      module: "COMPLIANCE",
      actorType: "ADMIN",
    });

    return updated;
  });
};

exports.rejectDataRequest = async (requestId, adminId) => {
  const updated = await prisma.dataRequest.update({
    where: { id: requestId },
    data: {
      status: "REJECTED",
      approvedById: adminId,
      approvedAt: new Date(),
    },
  });

  await logAudit({
    userId: adminId,
    entityType: "DATA_REQUEST",
    entityId: requestId,
    action: "DATA_REQUEST_REJECTED",
    module: "COMPLIANCE",
    actorType: "ADMIN",
  });

  return updated;
};

/*
|--------------------------------------------------------------------------
| PURGE QUEUE
|--------------------------------------------------------------------------
*/

exports.listPurgeQueue = async (query) => {
  const { status } = query;

  return prisma.purgeQueue.findMany({
    where: {
      ...(status && { status }),
    },
    orderBy: { createdAt: "desc" },
  });
};

exports.getPurgeQueueItem = async (queueId) => {
  return prisma.purgeQueue.findUnique({
    where: { id: queueId },
  });
};

exports.retryPurgeJob = async (queueId) => {
  const updated = await prisma.purgeQueue.update({
    where: { id: queueId },
    data: {
      status: "PENDING",
      attempts: { increment: 1 },
      lastError: null,
    },
  });

  await logAudit({
    userId: null,
    entityType: "PURGE_QUEUE",
    entityId: queueId,
    action: "PURGE_JOB_RETRIED",
    module: "COMPLIANCE",
    actorType: "ADMIN",
  });

  return updated;
};

/*
|--------------------------------------------------------------------------
| CONSENT LOGS (READ ONLY)
|--------------------------------------------------------------------------
*/

exports.listConsentLogs = async (query) => {
  const { userId, businessId, type } = query;

  return prisma.consentLog.findMany({
    where: {
      ...(userId && { userId }),
      ...(businessId && { businessId }),
      ...(type && { type }),
    },
    orderBy: { createdAt: "desc" },
  });
};

exports.getConsentLogById = async (logId) => {
  return prisma.consentLog.findUnique({
    where: { id: logId },
  });
};
