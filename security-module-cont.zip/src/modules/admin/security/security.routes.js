const express = require("express");
const router = express.Router();

const controller = require("./security.controller");
const auth = require("../../../middlewares/auth.middleware");
const requirePermission = require("../../../middlewares/permission.middleware");

/**
 * =====================================================
 * LOGIN ACTIVITY
 * =====================================================
 */

router.get(
  "/login-activities",
  auth,
  requirePermission("security", "read"),
  controller.getLoginActivities,
);

/**
 * =====================================================
 * AUDIT LOGS
 * =====================================================
 */

router.get(
  "/audit-logs",
  auth,
  requirePermission("security", "read"),
  controller.getAuditLogs,
);

router.get(
  "/audit-logs/:id",
  auth,
  requirePermission("security", "read"),
  controller.getAuditLogById,
);

/**
 * =====================================================
 * USER SESSIONS
 * =====================================================
 */

router.get(
  "/users/:userId/sessions",
  auth,
  requirePermission("security", "read"),
  controller.getUserSessions,
);

router.patch(
  "/users/sessions/:tokenId/revoke",
  auth,
  requirePermission("security", "update"),
  controller.revokeUserSession,
);

router.patch(
  "/users/:userId/sessions/revoke-all",
  auth,
  requirePermission("security", "update"),
  controller.revokeAllUserSessions,
);

/**
 * =====================================================
 * ADMIN SESSIONS
 * =====================================================
 */

router.get(
  "/admins/:adminId/sessions",
  auth,
  requirePermission("security", "read"),
  controller.getAdminSessions,
);

router.patch(
  "/admins/sessions/:tokenId/revoke",
  auth,
  requirePermission("security", "update"),
  controller.revokeAdminSession,
);

router.patch(
  "/admins/:adminId/sessions/revoke-all",
  auth,
  requirePermission("security", "update"),
  controller.revokeAllAdminSessions,
);

/**
 * =====================================================
 * TOKEN CONTROL
 * =====================================================
 */

router.patch(
  "/tokens/:tokenId/revoke",
  auth,
  requirePermission("security", "update"),
  controller.revokeToken,
);

/**
 * =====================================================
 * FRAUD FLAGS
 * =====================================================
 */

router.post(
  "/fraud/user",
  auth,
  requirePermission("security", "create"),
  controller.flagUser,
);

router.post(
  "/fraud/transaction",
  auth,
  requirePermission("security", "create"),
  controller.flagTransaction,
);

router.patch(
  "/fraud/:flagId/resolve",
  auth,
  requirePermission("security", "update"),
  controller.resolveFlag,
);

router.get(
  "/fraud",
  auth,
  requirePermission("security", "read"),
  controller.getFlags,
);

/**
 * =====================================================
 * SUSPICIOUS TRANSACTIONS
 * =====================================================
 */

router.get(
  "/suspicious-transactions",
  auth,
  requirePermission("security", "read"),
  controller.getSuspiciousTransactions,
);

router.patch(
  "/suspicious-transactions/:transactionId/mark-safe",
  auth,
  requirePermission("security", "update"),
  controller.markTransactionAsSafe,
);

/**
 * =====================================================
 * INTEGRITY CHECKS
 * =====================================================
 */

router.get(
  "/integrity-checks",
  auth,
  requirePermission("security", "read"),
  controller.runIntegrityChecks,
);

/**
 * =====================================================
 * SYSTEM ERROR LOGGING
 * =====================================================
 */

router.post(
  "/errors",
  auth,
  requirePermission("security", "create"),
  controller.logSystemError,
);

/**
 * =====================================================
 * FORCE LOGOUT
 * =====================================================
 */

router.patch(
  "/users/:userId/force-logout",
  auth,
  requirePermission("security", "update"),
  controller.forceLogoutUser,
);

module.exports = router;
