const Joi = require("joi");

/*
|--------------------------------------------------------------------------
| Reusable
|--------------------------------------------------------------------------
*/

const uuid = Joi.string().uuid();

/*
|--------------------------------------------------------------------------
| Login Activity
|--------------------------------------------------------------------------
*/

exports.getLoginActivities = Joi.object({
  userId: uuid.optional(),
  adminId: uuid.optional(),
});

/*
|--------------------------------------------------------------------------
| Audit Logs
|--------------------------------------------------------------------------
*/

exports.getAuditLogs = Joi.object({
  adminId: uuid.optional(),
  action: Joi.string().optional(),
});

exports.auditIdParam = Joi.object({
  id: uuid.required(),
});

/*
|--------------------------------------------------------------------------
| User Sessions
|--------------------------------------------------------------------------
*/

exports.userIdParam = Joi.object({
  userId: uuid.required(),
});

exports.tokenIdParam = Joi.object({
  tokenId: uuid.required(),
});

/*
|--------------------------------------------------------------------------
| Admin Sessions
|--------------------------------------------------------------------------
*/

exports.adminIdParam = Joi.object({
  adminId: uuid.required(),
});

/*
|--------------------------------------------------------------------------
| Fraud Flags
|--------------------------------------------------------------------------
*/

exports.flagUser = Joi.object({
  userId: uuid.required(),
  reason: Joi.string().min(3).required(),
});

exports.flagTransaction = Joi.object({
  transactionId: uuid.required(),
  reason: Joi.string().min(3).required(),
});

exports.flagIdParam = Joi.object({
  flagId: uuid.required(),
});

/*
|--------------------------------------------------------------------------
| Suspicious Transactions
|--------------------------------------------------------------------------
*/

exports.transactionIdParam = Joi.object({
  transactionId: uuid.required(),
});

/*
|--------------------------------------------------------------------------
| Integrity Checks
|--------------------------------------------------------------------------
*/

exports.runIntegrityChecks = Joi.object({});

/*
|--------------------------------------------------------------------------
| System Error Logging
|--------------------------------------------------------------------------
*/

exports.logSystemError = Joi.object({
  message: Joi.string().required(),
  stack: Joi.string().optional(),
});

/*
|--------------------------------------------------------------------------
| Force Logout
|--------------------------------------------------------------------------
*/

exports.forceLogoutUser = Joi.object({
  userId: uuid.required(),
});
