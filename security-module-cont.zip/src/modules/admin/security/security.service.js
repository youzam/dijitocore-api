const crypto = require("crypto");
const AppError = require("../../../utils/AppError");
const prisma = require("../../../config/prisma");

/**
 * =====================================================
 * LOGIN ACTIVITY LOGS (NEW)
 * =====================================================
 */

exports.getLoginActivities = async (filters = {}) => {
  return prisma.loginActivity.findMany({
    where: filters,
    orderBy: { createdAt: "desc" },
  });
};

/**
 * =====================================================
 * AUDIT LOGS (READ ONLY - INTEGRATION)
 * =====================================================
 */

exports.getAuditLogs = async (filters = {}) => {
  return prisma.adminAuditLog.findMany({
    where: filters,
    orderBy: { createdAt: "desc" },
  });
};

exports.getAuditLogById = async (id) => {
  const log = await prisma.adminAuditLog.findUnique({
    where: { id },
  });

  if (!log) {
    throw new AppError("audit.notFound", 404);
  }

  return log;
};

/**
 * =====================================================
 * SESSION MANAGEMENT
 * =====================================================
 */

/** USER SESSIONS */
exports.getUserSessions = async (userId) => {
  return prisma.refreshToken.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });
};

exports.revokeUserSession = async (tokenId) => {
  return prisma.refreshToken.update({
    where: { id: tokenId },
    data: { revokedAt: new Date() },
  });
};

exports.revokeAllUserSessions = async (userId) => {
  return prisma.refreshToken.updateMany({
    where: {
      userId,
      revokedAt: null,
    },
    data: {
      revokedAt: new Date(),
    },
  });
};

/** ADMIN SESSIONS (NEW) */
exports.getAdminSessions = async (adminId) => {
  return prisma.refreshToken.findMany({
    where: { adminId },
    orderBy: { createdAt: "desc" },
  });
};

exports.revokeAdminSession = async (tokenId) => {
  return prisma.refreshToken.update({
    where: { id: tokenId },
    data: { revokedAt: new Date() },
  });
};

exports.revokeAllAdminSessions = async (adminId) => {
  return prisma.refreshToken.updateMany({
    where: {
      adminId,
      revokedAt: null,
    },
    data: {
      revokedAt: new Date(),
    },
  });
};

/**
 * =====================================================
 * TOKEN CONTROL
 * =====================================================
 */

exports.revokeToken = async (tokenId) => {
  return prisma.refreshToken.update({
    where: { id: tokenId },
    data: {
      revokedAt: new Date(),
    },
  });
};

/**
 * =====================================================
 * FRAUD FLAGS
 * =====================================================
 */

exports.flagUser = async (userId, reason) => {
  return prisma.fraudFlag.create({
    data: {
      userId,
      reason,
      status: "ACTIVE",
    },
  });
};

exports.flagTransaction = async (transactionId, reason) => {
  return prisma.fraudFlag.create({
    data: {
      transactionId,
      reason,
      status: "ACTIVE",
    },
  });
};

exports.resolveFlag = async (flagId) => {
  return prisma.fraudFlag.update({
    where: { id: flagId },
    data: {
      status: "RESOLVED",
      resolvedAt: new Date(),
    },
  });
};

exports.getFlags = async (filters = {}) => {
  return prisma.fraudFlag.findMany({
    where: filters,
    orderBy: { createdAt: "desc" },
  });
};

/**
 * =====================================================
 * SUSPICIOUS TRANSACTIONS
 * =====================================================
 */

exports.getSuspiciousTransactions = async () => {
  return prisma.payment.findMany({
    where: {
      OR: [{ status: "FAILED" }, { flagged: true }],
    },
    orderBy: { createdAt: "desc" },
  });
};

exports.markTransactionAsSafe = async (transactionId) => {
  return prisma.payment.update({
    where: { id: transactionId },
    data: {
      flagged: false,
    },
  });
};

/**
 * =====================================================
 * INTEGRITY CHECK ENGINE (UNCHANGED)
 * =====================================================
 */

exports.runIntegrityChecks = async () => {
  const issues = [];

  const payments = await prisma.payment.findMany({
    select: { id: true, contractId: true },
  });

  const contracts = await prisma.contract.findMany({
    select: {
      id: true,
      totalValue: true,
      paidAmount: true,
      outstandingAmount: true,
    },
  });

  const contractMap = new Map(contracts.map((c) => [c.id, c]));

  const orphanPayments = payments.filter((p) => !contractMap.has(p.contractId));

  if (orphanPayments.length > 0) {
    issues.push({
      type: "orphan_payments",
      count: orphanPayments.length,
    });
  }

  contracts.forEach((contract) => {
    if (contract.paidAmount > contract.totalValue) {
      issues.push({
        type: "overpaid_contract",
        contractId: contract.id,
      });
    }

    if (contract.outstandingAmount < 0) {
      issues.push({
        type: "negative_outstanding",
        contractId: contract.id,
      });
    }
  });

  const scheduleAgg = await prisma.installmentSchedule.groupBy({
    by: ["contractId"],
    _sum: { amount: true },
  });

  scheduleAgg.forEach((s) => {
    const contract = contractMap.get(s.contractId);
    if (!contract) return;

    const totalScheduled = s._sum.amount || 0;

    if (totalScheduled !== contract.totalValue) {
      issues.push({
        type: "schedule_mismatch",
        contractId: s.contractId,
      });
    }
  });

  return issues;
};

/**
 * =====================================================
 * SYSTEM ERROR LOGGING
 * =====================================================
 */

const generateSignature = (message, stack) => {
  return crypto
    .createHash("sha256")
    .update(message + (stack || ""))
    .digest("hex");
};

exports.logSystemError = async (error) => {
  const signature = generateSignature(error.message, error.stack);

  let group = await prisma.systemErrorGroup.findUnique({
    where: { signature },
  });

  if (!group) {
    group = await prisma.systemErrorGroup.create({
      data: {
        signature,
        message: error.message,
        occurrence: 1,
      },
    });
  } else {
    await prisma.systemErrorGroup.update({
      where: { id: group.id },
      data: {
        occurrence: { increment: 1 },
      },
    });
  }

  return prisma.systemError.create({
    data: {
      groupId: group.id,
      stack: error.stack,
      environment: process.env.NODE_ENV || "development",
    },
  });
};

/**
 * =====================================================
 * FORCE LOGOUT
 * =====================================================
 */

exports.forceLogoutUser = async (userId) => {
  const user = await prisma.user.findUnique({
    where: { id: userId },
  });

  if (!user) {
    throw new AppError("auth.user_not_found", 404);
  }

  await prisma.refreshToken.updateMany({
    where: {
      userId,
      revokedAt: null,
    },
    data: {
      revokedAt: new Date(),
    },
  });

  return true;
};
