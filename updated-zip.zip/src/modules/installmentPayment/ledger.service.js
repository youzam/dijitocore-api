const ledgerService = require('../../../services/ledger.service');

const getTenantLedger = async ({ tenantId, page, limit }) => {
  const result = await ledgerService.getEntriesRaw({
    scopeType: 'TENANT',
    scopeId: tenantId,
    page,
    limit,
  });

  const formatted = result.data.map((entry) => ({
    id: entry.id,
    type: entry.referenceType,
    amount: entry.amount,
    status: entry.status || 'SUCCESS',
    createdAt: entry.createdAt,
  }));

  return {
    data: formatted,
    total: result.total,
    page: result.page,
    limit: result.limit,
  };
};

module.exports = {
  getTenantLedger,
};
