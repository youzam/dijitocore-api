const db = require('../config/prisma');
const PERMISSIONS = require('./permission.constants');

module.exports = async function checkPermissionIntegrity() {
  try {
    console.log('\n🔍 Checking permission integrity...\n');

    /*
    |--------------------------------------------------------------------------
    | 1. FETCH CURRENT PERMISSIONS
    |--------------------------------------------------------------------------
    */

    const dbPermissions = await db.permission.findMany({
      include: { rolePermissions: true },
    });

    const dbNames = dbPermissions.map((p) => p.name);
    const constantNames = Object.values(PERMISSIONS);

    /*
    |--------------------------------------------------------------------------
    | 2. SEED NEW PERMISSIONS
    |--------------------------------------------------------------------------
    */

    const missingInDB = constantNames.filter((p) => !dbNames.includes(p));

    let seeded = [];

    if (missingInDB.length > 0) {
      await db.permission.createMany({
        data: missingInDB.map((name) => ({ name })),
        skipDuplicates: true,
      });

      seeded = missingInDB;

      console.log(`✅ Seeded ${seeded.length} permissions`);
    }

    /*
    |--------------------------------------------------------------------------
    | 3. ENSURE SUPER_ADMIN ROLE EXISTS
    |--------------------------------------------------------------------------
    */

    let superAdminRole = await db.systemAdminRole.findFirst({
      where: { name: 'SUPER_ADMIN' },
    });

    if (!superAdminRole) {
      superAdminRole = await db.systemAdminRole.create({
        data: {
          name: 'SUPER_ADMIN',
        },
      });

      console.log('🔥 SUPER_ADMIN role created');
    }

    /*
    |--------------------------------------------------------------------------
    | 4. AUTO ASSIGN SUPER ADMIN (FIRST TIME ONLY)
    |--------------------------------------------------------------------------
    */

    let autoAssigned = [];

    try {
      const existingCount = await db.rolePermission.count({
        where: { role: 'SUPER_ADMIN' },
      });

      if (existingCount === 0) {
        const allPermissions = await db.permission.findMany();

        await db.rolePermission.createMany({
          data: allPermissions.map((p) => ({
            role: 'SUPER_ADMIN', // enum
            permissionId: p.id,
            systemAdminRoleId: superAdminRole.id,
          })),
          skipDuplicates: true,
        });

        autoAssigned = allPermissions.map((p) => p.name);

        console.log(
          `🔥 SUPER_ADMIN auto-assigned ${autoAssigned.length} permissions`,
        );
      }
    } catch (err) {
      console.error('❌ SUPER_ADMIN auto-assign failed:', err.message);
    }

    /*
    |--------------------------------------------------------------------------
    | 5. RELOAD AFTER ASSIGN
    |--------------------------------------------------------------------------
    */

    const finalPermissions = await db.permission.findMany({
      include: { rolePermissions: true },
    });

    /*
    |--------------------------------------------------------------------------
    | 6. UNASSIGNED (FINAL CHECK)
    |--------------------------------------------------------------------------
    */

    const unassigned = finalPermissions
      .filter((p) => p.rolePermissions.length === 0)
      .map((p) => p.name);

    if (unassigned.length > 0) {
      console.warn('\n⚠️ Unassigned permissions:\n');
      unassigned.forEach((p) => console.warn(`- ${p}`));
    }

    /*
    |--------------------------------------------------------------------------
    | RETURN RESULT
    |--------------------------------------------------------------------------
    */

    return {
      seeded,
      unassigned,
      autoAssigned,
    };
  } catch (err) {
    console.error('❌ Permission integrity failed:', err.message);
    throw err;
  }
};
